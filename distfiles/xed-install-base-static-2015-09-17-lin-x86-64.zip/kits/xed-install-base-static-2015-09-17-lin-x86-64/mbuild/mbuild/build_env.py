#!/usr/bin/env python
# -*- python -*-
#BEGIN_LEGAL
#Copyright 2004-2015 Intel Corporation. Use of this code is subject to
#the terms and conditions of the What If Pre-Release License Agreement,
#which is available here:
#https://software.intel.com/en-us/articles/what-if-pre-release-license-agreement
#or refer to the LICENSE.txt file.
#END_LEGAL

"""Setup functions for the ms/gnu compiler environment"""

import os
import sys
import platform
from base import *
from util import *
from env import *
import msvs


def set_compiler_env_common(env):
    """Set up some common stuff that depends heavily on the compiler setting"""
    
    # This whole section was really an experiment in how dynamically I
    # could do substitutions.
    
    env['debug_flag'] = ( 'debug', { True: '%(DEBUGFLAG)s',
                                     False:''})
    env['debug_flag_link'] = ( 'debug', { True: '%(DEBUGFLAG_LINK)s',
                                          False:''})

    win_shared_compile_dict = ( 'compiler', { 'ms': '/MD',
                                              'icl': '/MD', 
                                              'otherwise': '',
                                              })

    shared_compile_dict = ( 'host_os', { 'android': '-fPIC',
                                          'lin': '-fPIC',
                                          'win': win_shared_compile_dict,
                                          'bsd': '-fPIC',
                                          'otherwise': '',
                                          })
    
    env['shared_compile_flag'] =  ( 'shared', { True: shared_compile_dict,
                                                False:''})
    
    shared_link_dict =  ('compiler', { 'ms':'/dll',
                                       'icl':'/dll',
                                       'icc':'-shared',
                                       'gnu':'-shared'})
    
    env['shared_link'] = ( 'shared', { True:  shared_link_dict,
                                       False:''})
    
    env['OPTOPT'] = ( 'compiler', { 'gnu':'-O',
                                    'clang':'-O',
                                    'iclang':'-O',
                                    'icc':'-O',
                                    'icl':'/O',
                                    'ms':'/O'})

    env['nologo'] = ( 'compiler', { 'gnu':'',
                                    'clang':'',
                                    'iclang':'',
                                    'icc':'',
                                    'icl':'/nologo',
                                    'ms':'/nologo'})
    flags = ''
    flags += ' %(debug_flag)s'
    flags += ' %(nologo)s'
    flags += ' %(opt_flag)s'
    flags += ' %(shared_compile_flag)s'
    env['CCFLAGS'] = flags 
    env['CXXFLAGS'] = flags 
    env['LINKFLAGS'] += ' %(debug_flag_link)s'

def add_gnu_arch_flags(d):
    """Accept a dictionary, return a string"""
    if d['compiler'] in ['gnu','clang'] and d['gcc_version'] != '2.96': # FIXME: iclang?
        if d['host_cpu'] == 'x86-64':
            return '-m64'
        elif d['host_cpu'] == 'ia32':
            return '-m32'
    return ''
    

def set_env_gnu(env):
    """Example of setting up the GNU GCC environment for compilation"""
    set_compiler_env_common(env)

    env['opt_flag'] = ( 'opt', {'noopt':'',
                                's':'%(OPTOPT)ss',
                                '0':'%(OPTOPT)s0',
                                '1':'%(OPTOPT)s1',
                                '2':'%(OPTOPT)s2',
                                '3':'%(OPTOPT)s3',
                                '4':'%(OPTOPT)s4'} )

    # lazy toolchain and other env var (f)  expansion
    mktool = lambda(f): "%(toolchain)s%(" + f + ")s" 

    if env['CXX_COMPILER'] == '':
        env['CXX_COMPILER'] = ( 'compiler', { 'gnu':'g++',
                                              'icc':'icpc',
                                              'iclang':'icl++',
                                              'clang':'clang++'})
    if env['CC_COMPILER'] == '':
        env['CC_COMPILER'] =  ( 'compiler', { 'gnu':'gcc',
                                              'icc':'icc',
                                              'iclang':'icl',
                                              'clang':'clang' })
    if env['ASSEMBLER'] == '':
        env['ASSEMBLER'] =  ( 'compiler', { 'gnu':'gcc',
                                            'icc':'icc',
                                            'iclang':'icl',
                                            'clang':'yasm' })

    if env['LINKER'] == '':
        env['LINKER'] = '%(CXX_COMPILER)s' # FIXME C++ or C?  
    if env['ARCHIVER'] == '':
        env['ARCHIVER'] = ( 'compiler', { 'gnu': 'ar',    # or GAR??
                                          'icc' : 'xiar',
                                          'iclang' : 'xiar',
                                          'clang':'ar' })
    if env['RANLIB_CMD'] == '':
        env['RANLIB_CMD'] = 'ranlib'

    if env['CC'] == '':
        env['CC'] = mktool('CC_COMPILER')
    if env['CXX'] == '':
        env['CXX'] =  mktool('CXX_COMPILER')
    if env['AS'] == '':
        env['AS'] =  mktool('ASSEMBLER')
    if env['LINK'] == '':
        env['LINK'] = mktool('LINKER')
    if env['AR'] == '':
        env['AR'] = mktool('ARCHIVER')
    if env['RANLIB'] == '':
        env['RANLIB'] = mktool('RANLIB_CMD')

    # if using gcc to compile include -c. If using gas, omit the -c
    env['ASFLAGS'] = ' -c'

    env['ARFLAGS'] = "rcv"
    env['STATIC'] = (  'static', { True :  "-static", 
                                   False : "" } )
    env['LINKFLAGS'] += " %(STATIC)s"

    env['GNU64'] = add_gnu_arch_flags # dynamically called function during variable expansion!
    s = ' %(GNU64)s'
    env['CCFLAGS']  += s
    env['CXXFLAGS']  += s
    env['LINKFLAGS'] += s
    # if using gcc to compile use -m64, otherwise if gas is used, omit the -m64.
    env['ASFLAGS'] += s
    
    env['DEBUGFLAG'] = '-g' 
    env['DEBUGFLAG_LINK'] = '-g' 
    env['COPT'] = '-c'
    env['DOPT'] = '-D'
    env['ASDOPT'] = '-D'
    env['IOPT'] = '-I'
    env['ISYSOPT'] = '-isystem ' # trailing space required
    env['LOPT'] = '-L'
 
    env['COUT'] = '-o '
    env['ASMOUT'] = '-o '
    env['LIBOUT'] = ' ' # nothing when using gar/ar
    env['LINKOUT'] = '-o '
    env['EXEOUT'] = '-o '
    if env.on_mac():
        env['DLLOPT'] = '-shared' # '-dynamiclib'
    else:
        env['DLLOPT'] = '-shared -Wl,-soname,%(SOLIBNAME)s'

    env['OBJEXT'] = '.o'
    if env.on_windows():
        env['EXEEXT'] = '.exe'
        env['DLLEXT'] = '.dll'
        env['LIBEXT'] = '.lib'
        env['PDBEXT'] = '.pdb'
    elif env.on_mac():
        env['EXEEXT'] = ''
        env['DLLEXT'] = '.dylib'
        env['LIBEXT'] = '.a'
        env['PDBEXT'] = ''
    else:
        env['EXEEXT'] = ''
        env['DLLEXT'] = '.so'
        env['LIBEXT'] = '.a'
        env['PDBEXT'] = ''



def find_ms_toolchain(env):
    if env['msvs_version']:
        env['setup_msvc']=True

    if env['vc_dir'] == '' and not env['setup_msvc']:
        if 'MSVCDir' in os.environ:
            vs_dir = os.environ['MSVCDir']
            if os.path.exists(vs_dir):
                env['vc_dir'] = vs_dir
        elif 'VCINSTALLDIR' in os.environ: 
            vc_dir = os.environ['VCINSTALLDIR']
            if os.path.exists(vc_dir):
                env['vc_dir'] = vc_dir
                msvs7 = os.path.join(env['vc_dir'],"Vc7") 
                if os.path.exists(msvs7):
                    env['vc_dir'] = msvs7
        elif 'VSINSTALLDIR' in os.environ: 
            vs_dir = os.environ['VSINSTALLDIR']
            if os.path.exists(vs_dir):
                env['vc_dir'] = os.path.join(vs_dir, 'VC')
        elif 'MSVCDIR' in os.environ:
            vs_dir = os.environ['MSVCDIR']
            if os.path.exists(vs_dir):
                env['vc_dir'] = vs_dir

    if env['vc_dir'] == '' or env['setup_msvc']:
        env['vc_dir'] = msvs.set_msvs_env(env)

    # toolchain is the bin directory of the compiler with a trailing slash
    if env['toolchain'] == '' and env['vc_dir'] and env['compiler']=='ms':
        toolchain = ''
        if env['build_cpu'] == 'ia32' and env['host_cpu'] == 'ia32':
            toolchain = os.path.join(env['vc_dir'], 'bin', '')
        elif env['build_cpu'] == 'ia32' and env['host_cpu'] == 'x86-64':
            toolchain = os.path.join(env['vc_dir'], 'bin', 'x86_amd64', '')
        elif env['build_cpu'] == 'x86-64' and env['host_cpu'] == 'x86-64':
            toolchain = os.path.join(env['vc_dir'], 'bin', 'amd64', '')
        elif env['build_cpu'] == 'x86-64' and env['host_cpu'] == 'ia32':
            toolchain = os.path.join(env['vc_dir'], 'bin', '')
        elif env['compiler'] == 'ms':
            die("Unknown build/target combination. build cpu=%s, " + 
                "host_cpu=%s" % ( env['build_cpu'], env['host_cpu']))

        env['toolchain'] = toolchain  # default toolchain that we discover

        

def set_env_ms(env):
    """Example of setting up the MSVS environment for compilation"""
    set_compiler_env_common(env)

    # FIXME: allow combinations of options
    env['opt_flag'] = ( 'opt', {'noopt':'',
                                '0':'%(OPTOPT)sd',
                                '1':'%(OPTOPT)s1',
                                '2':'%(OPTOPT)s2',
                                '3':'%(OPTOPT)s2', # map O3 and O4 to O2
                                '4':'%(OPTOPT)s2', # map O3 and O4 to O2
                                'b':'%(OPTOPT)sb',
                                'i':'%(OPTOPT)si',
                                'x':'%(OPTOPT)sx',
                                'd':'%(OPTOPT)sd',
                                'g':'%(OPTOPT)sg'} )

    env['ASFLAGS'] = '/c /nologo '
    env['LINKFLAGS']  += ' /nologo'
    env['ARFLAGS']     = '/nologo'

    env['link_prefix'] = ('use_compiler_to_link', { True:'/link', 
                                                    False:'' })
    if env['host_cpu'] == 'ia32':
        env['LINKFLAGS'] += ' %(link_prefix)s /MACHINE:X86'
        env['ARFLAGS']   += ' /MACHINE:X86'
    elif env['host_cpu'] == 'x86-64':
        env['LINKFLAGS'] += ' %(link_prefix)s /MACHINE:X64'
        env['ARFLAGS']   += ' /MACHINE:X64'

        env['favor'] = ( 'compiler', { 'ms'        : ' /favor:EM64T', 
                                       'otherwise' : '' })
        env['CXXFLAGS'] += ' %(favor)s'
        env['CCFLAGS']  += ' %(favor)s'
                          
    elif env['host_cpu'] == 'ipf':
        env['LINKFLAGS'] += ' %(link_prefix)s /MACHINE:IA64'
        env['ARFLAGS']   += ' /MACHINE:IA64'

    env['COPT'] = '/c'
    env['DOPT'] = '/D'
    env['ASDOPT'] = '/D'
    
    # I use '-I' instead of '/I' because it simplifies use of YASM
    # which requires -I for includes.
    env['IOPT'] = '-I' # -I or /I works with MSVS8.
    env['ISYSOPT'] = '-I' # MSVS has not -isystem so we use -I
    env['LOPT'] = '%(link_prefix)s /LIBPATH:'

    
    # Some options differ when using the compiler to link programs.
    # Note: /Zi has parallel-build synchronization bugs
    env['DEBUGFLAG'] = '/Z7'
    env['DEBUGFLAG_LINK'] = ('use_compiler_to_link', { True:'/Z7', # of /Zi
                                                       False:'/debug'})
    env['COUT'] = '/Fo'
    env['ASMOUT'] = '/Fo'
    env['LIBOUT'] = '/out:'
    env['EXEOUT'] = '/Fe'
    env['LINKOUT'] = ('use_compiler_to_link',{ True:'/Fo',
                                               False:'/OUT:'})
    env['DLLOPT'] = '/dll'
    env['OBJEXT'] = '.obj'
    env['LIBEXT'] = '.lib'
    env['DLLEXT'] = '.dll'
    env['EXEEXT'] = '.exe'
    env['PDBEXT'] = '.pdb'
    env['PDBEXT'] = '.pdb'
    env['RCEXT']  = '.rc'
    env['RESEXT'] = '.res'



    find_ms_toolchain(env)
    
    if env['ASSEMBLER'] == '':
        if env['host_cpu'] == 'ia32':
            env['ASSEMBLER'] = 'ml.exe'
        elif env['host_cpu'] == 'x86-64':
            env['ASSEMBLER'] = 'ml64.exe'

    if env['CXX_COMPILER'] == '':
        env['CXX_COMPILER'] = ( 'compiler', { 'ms':'cl.exe',
                                              'icl':'icl.exe' })
    if env['CC_COMPILER'] == '':
        env['CC_COMPILER'] = ( 'compiler', { 'ms':'cl.exe',
                                             'icl':'icl.exe' })
    if env['LINKER'] == '':
        env['LINKER'] = ( 'compiler', { 'ms': 'link.exe',
                                        'icl' : 'xilink.exe'})

    # old versions of RC do not accept the /nologo switch
    env['rcnologo'] = ( 'msvs_version', { 'otherwise':' /nologo',
                                          '6':'',
                                          '7':'',
                                          '8':'',
                                          '9':'' })
    env['RCFLAGS'] = " %(rcnologo)s"

    # Finding the rc executable is a bit of a nightmare.
    #
    # In MSVS2005(VC8):
    #     C:/Program Files (x86)/Microsoft Visual Studio 8/VC
    #         bin/rc.exe  
    #       or
    #         PlatformSDK/Bin/win64/AMD64/rc.exe
    #   which is $VCINSTALLDIR/bin or 
    #            $VCINSTALLDIR/PlatformSDK/bin/win64/AMD64
    #   We do not bother attempting to find that version of rc.
    #   Put it on your path or set env['RC_CMD'] if you need it.
    #
    # In MSVS2008(VC9), MSVS2010 (VC10) and MSVS2012 (VC11):
    #   have rc.exe in the SDK directory, though the location varies
    #   a little for the 32b version.

    if env['RC_CMD'] == '':
        if 'WindowsSdkDir' in env:
            sdk = env['WindowsSdkDir']
        elif 'WindowsSdkDir' in os.environ:
            sdk = os.environ['WindowsSdkDir']
        else:
            sdk = 'unknown-sdk-dir'
            # and hope the user puts it on their PATH
            env['RC_CMD'] = 'rc' 

        # if we have no valid sdk dir, we won't die trying to 
        # find the rc.exe.
        if sdk != 'unknown-sdk-dir':
            if env['host_cpu'] == 'x86-64':
                env['RC_CMD'] = os.path.join(sdk,'bin','x64','rc.exe')
                if not os.path.exists(env.expand('%(RC_CMD)s')):
                    die("Could not find 64b RC command in SDK directory")
            else:
                env['RC_CMD'] = os.path.join(sdk,'bin','x86','rc.exe')
                if not os.path.exists(env.expand('%(RC_CMD)s')):
                    env['RC_CMD'] = os.path.join(sdk,'bin','rc.exe')
                if not os.path.exists(env.expand('%(RC_CMD)s')):
                    die("Could not find 32b RC command in SDK directory")

    # RC lives in the SDK. Counting on the msvs.py setup to
    # put it on the PATH. FIXME
    if env['RC'] == '':
        env['RC']  = quote('%(RC_CMD)s')

    if env['ARCHIVER'] == '':
        env['ARCHIVER'] =( 'compiler', { 'ms': 'lib.exe',
                                         'icl' : 'xilib.exe'})
    # lazy toolchain and other env var (f)  expansion
    mktool = lambda(f): "%(toolchain)s%(" + f + ")s" 

    if env['CXX'] == '':
        env['CXX']  = quote(mktool('CXX_COMPILER'))
    if env['CC'] == '':
        env['CC']   = quote(mktool('CC_COMPILER'))
    if env['AS'] == '':
        env['AS']   = quote(mktool('ASSEMBLER'))
    if env['LINK'] == '':
        env['LINK'] = quote(mktool('LINKER'))
    if env['AR'] == '':
        env['AR']   = quote(mktool('ARCHIVER'))

        

def yasm_support(env):
    """Initialize the YASM support based on the env's host_os and host_cpu"""
    # FIXME: android???
    yasm_formats={}
    yasm_formats['win'] = { 'ia32': 'win32', 'x86-64': 'win64'}
    yasm_formats['lin'] = { 'ia32': 'elf32', 'x86-64': 'elf64'}
    yasm_formats['bsd'] = { 'ia32': 'elf32', 'x86-64': 'elf64'}
    yasm_formats['mac'] = { 'ia32': 'macho32', 'x86-64': 'macho64'}
    env['ASDOPT']='-D'
    try:
        env['ASFLAGS'] = ' -f' + yasm_formats[env['host_os']][env['host_cpu']]
    	env['ASMOUT'] = '-o '
        env['AS'] = 'yasm'
    except:
        die("YASM does not know what format to use for build O/S: %s and target CPU: %s" %
            (env['host_os'], env['host_cpu']))
            


def set_env_clang(env):
    set_env_gnu(env)


def set_env_icc(env):
    """Example of setting up the Intel ICC  environment for compilation"""
    set_env_gnu(env)

def set_env_iclang(env):
    """Example of setting up the Intel iclang (aka mac icl) environment for compilation"""
    set_env_gnu(env)
    
def set_env_icl(env):
    """Example of setting up the Intel ICL (windows) environment for compilation"""
    set_env_ms(env)
