#define UNW_LOCAL_ONLY
#include "mk_Gcursor_i.c"
